import React from 'react';
import { Route } from 'react-router';
import {BrowserRouter as Router,Routes} from 'react-router-dom'
import CardDetails from './component/CadDetails'
import CardList from './component/CadList'
import './App.css';


const App = () => (
       <>
         <Router>
          <Routes>
                <Route path="/" element={<CardList />} />
                <Route path="/details/:id" element={<CardDetails />} />
            </Routes>
      </Router>
       </>
)

export default App
