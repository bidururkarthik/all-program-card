import React from 'react';
import { Link } from 'react-router-dom';
import './index.css';

const AllProgram = (props) => {
    const { details } = props;
    const { id, title, image, description } = details;

    return (
        <Link to={`/details/${id}`}>
            <div className="col-12 col-md-3">
                <div className="card">
                    <div className="card-inner">
                        <div className="card-front">
                            <img src={image} className="wcu-card-image" alt={title} />
                            <h1 className="title">{title}</h1>
                        </div>
                        <div className="card-back">
                            <p>{description}</p>
                            <Link to={`/details/${id}`} className="btn-53">
                                <div className="original">Learn more</div>
                                <div className="letters">
                                    <span>L</span>
                                    <span>e</span>
                                    <span>a</span>
                                    <span>r</span>
                                    <span>n</span>
                                    <span>-</span>
                                    <span>M</span>
                                    <span>o</span>
                                    <span>r</span>
                                    <span>e</span>
                                </div>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </Link>
    );
};

export default AllProgram;
